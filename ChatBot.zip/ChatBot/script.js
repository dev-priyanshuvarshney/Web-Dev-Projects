let prompt = document.querySelector("#prompt")
let submitbtn = document.querySelector("#submit")
let chatContainer = document.querySelector(".chat-container")
let imagebtn = document.querySelector("#image")
let image = document.querySelector("#image img")
let imageinput=document.querySelector("#image input")
const Api_Url="https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyBhfhiI1ks1hSvtusc1ZFBWMOxDOWB8-hg"
let user={
    message:null,    
    file:{
         mime_type:null,
          data: null
    }
}

async function generateResponse(aiChatBox) {
    let text = aiChatBox.querySelector(".ai-chat-area")
    let RequestOption={
        method:"POST",
        headers:{'Content-Type' : 'application/json'},
        body:JSON.stringify({
            "contents": [
                {"parts":[{"text":user.message},(user.file.data?[{"inline_data":user.file}]:[])]}
            ]
        })
    }
    try{
        let response = await fetch(Api_Url,RequestOption)
        let data = await response.json()
        let apiResponse= data.candidates[0].content.parts[0].text.replace(/\*\*(.*?)\*\*/g,"$1").trim()
        text.innerHTML=apiResponse
        console.log(apiResponse);
        
    }
    catch(error){
        console.log(error);
    }
    finally{
        chatContainer.scrollTo({top:chatContainer.scrollHeight,behavior:"smooth"})
        image.src=`./assests/image.svg`
        image.classList.remove("choose")
        user.file={}
    }
}
function createChatBox(html, classes){
    let div = document.createElement("div")
    div.innerHTML=html
    div.classList.add(classes)
    return div
}


imageinput.addEventListener("change", () => {
    const file = imageinput.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
        alert('Please upload an image file');
        return;
    }

    let reader = new FileReader();
    reader.onload = (e) => {
        // Get full base64 string with data prefix
        const fullBase64 = e.target.result;
        const base64String = fullBase64.split(",")[1];
        
        user.file = {
            mime_type: file.type,
            data: base64String
        };

        // Create thumbnail preview (directly use the full base64 URL)
        image.src = fullBase64;
        image.classList.add("choose");
    };
    reader.readAsDataURL(file);
});

// Update the handleChatResponse image HTML generation
function handleChatResponse(message) {
    user.message = message;
    let imageHTML = '';
    
    if(user.file.data) {
        // Use the full base64 data URL format
        imageHTML = `
            <img src="data:${user.file.mime_type};base64,${user.file.data}" 
                 class="chooseimg"
                 alt="Uploaded content">
        `;
    }

    let html = `
        <img src="./assests/user.png" alt="User" id="userImage" width="60">
        <div class="user-chat-area">
            ${user.message ? `<div>${user.message}</div>` : ''}
            ${imageHTML}
        </div>
    `;
    
    // Rest of the function remains the same
    prompt.value = "";
    let userChatBox = createChatBox(html, "user-chat-box");
    chatContainer.appendChild(userChatBox);
    chatContainer.scrollTo({top: chatContainer.scrollHeight, behavior: "smooth"});

    setTimeout(() => {
        let html = `<img src="./assests/chatbot.png" alt="ChatBot" id="aiImage" width="60">
                    <div class="ai-chat-area">
                        <img src="./assests/loading.gif" alt="" class="load" width="200px">
                    </div>`;
        let aiChatBox = createChatBox(html, "ai-chat-box");
        chatContainer.appendChild(aiChatBox);
        generateResponse(aiChatBox);
    }, 600);
}

prompt.addEventListener("keydown",(e)=>{
    if(e.key=="Enter"){
        handleChatResponse(prompt.value)
    }  
})
submitbtn.addEventListener("click",()=>{
    handleChatResponse(prompt.value)
})
imageinput.addEventListener("change", () => {
    const file = imageinput.files[0];
    if (!file) return;
    
    // Validate image file
    if (!file.type.startsWith('image/')) {
        alert('Please upload an image file');
        return;
    }

    let reader = new FileReader();
    reader.onload = (e) => {
        let base64String = e.target.result.split(",")[1];
        user.file = {
            mime_type: file.type,
            data: base64String
        };
        
        // Create thumbnail preview
        const img = new Image();
        img.src = e.target.result;
        img.onload = () => {
            // Create canvas for thumbnail
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            
            // Set thumbnail dimensions
            canvas.width = 50;
            canvas.height = 50;
            
            // Draw image to canvas
            ctx.drawImage(img, 0, 0, 50, 50);
            
            // Update button preview
            image.src = canvas.toDataURL();
            image.classList.add("choose");
        };
    };
    reader.readAsDataURL(file);
});
imagebtn.addEventListener("click",()=>{
    imagebtn.querySelector("input").click()
})


// Open login popup
document.getElementById('login-btn').addEventListener('click', function() {
    const loginWindow = window.open('./Login/index.html', 'LoginWindow', 
        'width=2000,height=1000,top=0,left=0,right=0,bottom=0');
    
    // Listen for message from login window
    window.addEventListener('message', function(e) {
        if (e.origin !== window.location.origin) return; // Security check
        
        if (e.data === 'loginSuccess') {
            loginWindow.close();
            // Optional: Update UI to show logged-in state
            console.log('User logged in successfully!');
        }
    });
});